class Student {
  final String srNo;
  final String rollNo;
  final String name;
  final String tenth;
  final String twelfth;
  final String sem1;
  final String sem2;

  Student({
    required this.srNo,
    required this.rollNo,
    required this.name,
    required this.tenth,
    required this.twelfth,
    required this.sem1,
    required this.sem2,
  });

  factory Student.fromJson(Map<String, dynamic> json) {
    String s(String k) => (json[k] ?? '').toString();
    return Student(
      srNo: s('srNo'),
      rollNo: s('rollNo'),
      name: s('name'),
      tenth: s('tenth'),
      twelfth: s('twelfth'),
      sem1: s('sem1'),
      sem2: s('sem2'),
    );
  }
}
