import 'package:flutter/material.dart';
import '../models/student.dart';

class DetailScreen extends StatelessWidget {
  final Student student;
  const DetailScreen({super.key, required this.student});

  Widget _row(String label, String value) {
    return Card(
      child: ListTile(
        title: Text(label),
        trailing: Text(
          value,
          style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(student.name)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Roll No: ${student.rollNo}',
            style: const TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 12),
          _row('10th', student.tenth),
          _row('12th', student.twelfth),
          _row('Sem 1', student.sem1),
          _row('Sem 2', student.sem2),
        ],
      ),
    );
  }
}
