import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/student.dart';

// Paste your Apps Script Web app URL (must end with /exec)
const String apiUrl = 'PASTE_YOUR_WEB_APP_URL_HERE';

Future<List<Student>> fetchStudents() async {
  final response = await http.get(Uri.parse(apiUrl));
  if (response.statusCode == 200) {
    final List<dynamic> data = jsonDecode(response.body);
    return data
        .map((e) => Student.fromJson(e as Map<String, dynamic>))
        .toList();
  } else {
    throw Exception('Failed to load students (${response.statusCode})');
  }
}
